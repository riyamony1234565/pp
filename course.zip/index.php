<?php 
require 'dbcon.php';
if(isset($_POST['submit'])){
$course=$_POST['course'];
$course_outline=$_POST['course_outline'];
$course_fee=$_POST['course_fee'];
$course_type=$_POST['course_type'];
$status=$_POST['status'];
$photo_name=$_FILES['photo']['name'];
$photo_path=$_FILES['photo']['tmp_name'];
$course_outline=implode(',',$course_outline);

$insert=mysqli_query($conn,"INSERT INTO `course_list`(`course`, `course_outline`, `course_fee`, `status`, `course_type`, `photo`) VALUES ('$course','$course_outline','$course_fee','$status','$course_type','$photo_name')");
if($insert){
	move_uploaded_file($photo_path,"img/$photo_name");
	echo '<script>
		alert("Successfully Inserted");
		window.location.href="index.php";
	</script>
	';
	$course=false;
$course_outline=false;
$course_fee=$false;
$course_type=false;
$status=$false;
}
}
?>

<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body>
	<div class="container">
		<form action="" method="POST" enctype="multipart/form-data">
			<div class="input-group">
			<label for="course">Course</label>
			<input type="text" name="course" id="" />
			</div>
				<div class="input-group">
			<label for="course">Course Outline</label>
			<input type="checkbox" name="course_outline[]" value="Microsoft Word" id="" />Microsoft Word
			<input type="checkbox" name="course_outline[]" value="Microsoft Excel" id="" />Microsoft Excel
			<input type="checkbox" name="course_outline[]" value="Microsoft PowerPoint" id="" />Microsoft PowerPoint
			
			</div>
				<div class="input-group">
			<label for="">Course Fee</label>
			<input type="text" name="course_fee" id="" />
			</div>
				<div class="input-group">
			<label for="">Course Type</label>
		<select name="course_type" id="">
			<option value="Online">Online</option>
			<option value="Offline">Offline</option>
			</select>
			</div>
				<div class="input-group">
			<label for="">Status</label>
			<select name="status" id="">
			<option value="Active">Active</option>
			<option value="Inactive">Inactive</option>
			</select>
			</div>
					<div class="input-group">
			<label for="">Course Photo</label>
			<input type="file" name="photo" id="" />
			</div>
			<div class="btn">
			<input type="submit" name="submit" value="Submit" />
			</div>
			
		</form>
	</div>
	<div class="data">
		<table border="1">
			<tr>
				<td>Id</td>
				<td>Course</td>
				<td>Course Outline</td>
				<td>Course Fee</td>
				<td>Course Type</td>
				<td>Photo</td>
				<td>Status</td>
			
			</tr>
			<?php 
				$select_data=mysqli_query($conn,"SELECT * FROM `course_list`");
				while($rows=mysqli_fetch_assoc($select_data)){
					
					?>
				<tr>
				<td><?=$rows['id']?></td>
				<td><?=$rows['course']?></td>
				<td>
					<ol>
					<?php
						$course_outline_array=explode(',',$rows['course_outline']);
						foreach($course_outline_array as $value){
							?>
							
								<li><?=$value?></li>
							
							<?php
						}
					?>

					</ol>
				</td>
				<td><?=$rows['course_fee']?></td>
				<td><?=$rows['course_type']?></td>
				<td><img width="200" height="60" src="img/<?=$rows['photo']?>" alt=""></td>
				<td><?=$rows['status']?></td>
				</tr>

<?php
				}
			?>
		</table>
	</div>
</body>
</html>