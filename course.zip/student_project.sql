-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 24, 2025 at 05:36 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `student_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `course_list`
--

CREATE TABLE `course_list` (
  `id` int(11) NOT NULL,
  `course` varchar(255) NOT NULL,
  `course_outline` varchar(555) NOT NULL,
  `course_fee` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `course_type` varchar(50) NOT NULL,
  `photo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `course_list`
--

INSERT INTO `course_list` (`id`, `course`, `course_outline`, `course_fee`, `status`, `course_type`, `photo`) VALUES
(1, 'Computer Office Application', 'Microsoft Word,Microsoft Excel,Microsoft PowerPoint', '5000', 'Active', 'Online', 'office-application.jpg'),
(2, 'Computer Office Application', 'Microsoft Word,Microsoft Excel,Microsoft PowerPoint', '5000', 'Active', 'Online', 'office-application.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `dob` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  `join_date` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `dob`, `email`, `mobile`, `password`, `join_date`) VALUES
(44020002, 'Mohsina', '1997-05-1', 'zahidcomputer2468@gmail.com', '01928248173', '25f9e794323b453885f5181f1b624d0b', '2024-12-02'),
(44020008, 'rana', '2024-01-01', 'rana@gmail.com', '01954487920', '202cb962ac59075b964b07152d234b70', '2024-12-09'),
(44020009, 'Md Zahid Hossain', '2024-01-01', 'zahid@gmail.com', '01928248173', 'df6d2338b2b8fce1ec2f6dda0a630eb0', '2024-12-09'),
(44020012, 'Md Imran Rana', '2024-01-01', 'adminzahid@gmail.com', '01701900007', '25f9e794323b453885f5181f1b624d0b', '2024-12-18');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `course_list`
--
ALTER TABLE `course_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `course_list`
--
ALTER TABLE `course_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44020013;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
